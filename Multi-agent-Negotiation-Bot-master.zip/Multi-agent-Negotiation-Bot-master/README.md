# Multi-agent-Negotiation-Bot
An automated negotiation bot which runs on GENIUS platform. The agent participates in a multi-party negotiation. It follows an alternating offers protocol.
